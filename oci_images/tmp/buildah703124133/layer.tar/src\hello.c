#include <stdlib.h>
#include <stdio.h>

void print(){
    printf("this is hello.c\n");
}